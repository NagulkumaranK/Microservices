package com.example.loginandregister.security;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.loginandregister.entity.Customer;
import com.example.loginandregister.repo.CustomerRepo;

@Service
public class CustomerDetailsService implements UserDetailsService {

	@SuppressWarnings("unused")
	@Autowired
	private CustomerRepo customerRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Customer existingCustomer = customerRepo.findByUsername(username).orElseThrow(() -> 
		new UsernameNotFoundException("User not found"));

		return new org.springframework.security.core.userdetails.User(
				existingCustomer.getUsername(), existingCustomer.getPassword(), new ArrayList<>());
	}

}
